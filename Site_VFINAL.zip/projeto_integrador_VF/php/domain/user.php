<?php 
class User {
    // Properties
    public $id;
    public $nome;
    public $username;
    public $dataNasc;
    public $email;
 
    /*public function getNome() {
        return $this->nome;
    }
 
    public function setNome($nome) {
        $this->nome = $nome;
    }
 
    public function getUsername() {
        return $this->username;
    }
 
    public function setUsername($username) {
        $this->username = $username;
    }
    public function getDataNasc() {
        return $this->username;
    }
 
    public function setDataNasc($dataNasc) {
        $this->dataNasc = $dataNasc;
    }*/
}
?>